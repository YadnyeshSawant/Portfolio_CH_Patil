<?php
$con=mysqli_connect("localhost","chpatilc","h_5Ov$6BwI","chpatilc_ch_patil");
?>