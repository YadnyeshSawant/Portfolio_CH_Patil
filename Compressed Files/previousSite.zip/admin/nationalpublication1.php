<?php
session_start();
include('db.php');

$np=$_POST["np"];



$r=mysqli_query($con,"select * from nationalpublication where np='$np'");
if($row=mysqli_fetch_array($r))
	echo "Already Exists";
else{
$rn=mysqli_query($con,"insert into nationalpublication(np)values('$np')");

if($rn)
{
	 $_SESSION["addnp"]="Your National Publication added Successfully";
    header("location:nationalpublication.php");
}
else
{
echo mysqli_error($con);
}
}
?>