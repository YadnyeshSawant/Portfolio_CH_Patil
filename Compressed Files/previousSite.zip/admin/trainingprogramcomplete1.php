<?php
session_start();
include('db.php');

$tp=$_POST["tp"];



$r=mysqli_query($con,"select * from trainingprogram where tp='$tp'");
if($row=mysqli_fetch_array($r))
	echo "Already Exists";
else{
$rn=mysqli_query($con,"insert into trainingprogram(tp)values('$tp')");

if($rn)
{
	 $_SESSION["addtp"]="Your Training Program added Successfully";
    header("location:trainingprogramcomplete.php");
}
else
{
echo mysqli_error($con);
}
}
?>