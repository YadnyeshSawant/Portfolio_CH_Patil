<script>
   function del()
{
	 var vol=confirm("Do you want to delete this detail");
	 if(vol)
		 return true;
	 else
		 return false;
}
</script>
<?php
include('head.php');
?>
<form name='mine' action='nationalpublication1.php' method='post' onsubmit='return valid()'>
<br/><table border='1' cellspacing=0 cellpadding=10 class='table table-bordered' align='center'>
<tr>
<td colspan='2' align='center' style='color:green'>
   <?php
     if(isset($_SESSION["addnp"]))
		 echo $_SESSION["addnp"];
   ?>
</td>
</tr>
<tr>
	<td colspan="2" align="center" style="font-weight:bold;font-size:large;">National Publication</td>
</tr>
   <tr><td><b>National Publication</b></td>
   <td><input type='text' name='np' value='' class='form-control' placeholder='Enter National Publication' ></td>
   </tr>
   
   <tr>
   <td align='center' colspan='2'><input type='submit'  class='btn btn-primary'value='Submit'>
   <input type='reset' value='Cancel' class='btn btn-danger'></td>
   </tr>
</table>
</form>

<!-- Lecturer -->
<?php
 
include('db.php');
$r=mysqli_query($con,"select * from nationalpublication order by id desc");

echo "<table border='1' cellspacing=0 width='100%' id='example' 
class='display table table-bordered' cellpadding=10 align='center'>";

echo "<thead><tr><th>SNO.</th><th>National Publication</th><th>Delete</th></tr></thead><tbody>";

$sno=1;
while($row=mysqli_fetch_array($r))
{
	 echo "<tr><td align='center'>",($sno++),"</td>";
	 echo "<td align='center'>$row[1]</td>";
	
	echo  "<td><a class='btn btn-danger' href='delete_np.php?a=$row[0]' onclick='return del()'>Delete</a></td></tr>";
}
    echo "</tbody></table>";
?>
<?php
include('footer.php');
echo $_SESSION["addnp"]='';
?>