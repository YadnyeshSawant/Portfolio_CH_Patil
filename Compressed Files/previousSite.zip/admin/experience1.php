<?php
session_start();
include('db.php');

$lec=$_POST["lecturer"];
$lecd=$_POST["lecdate"];


$r=mysqli_query($con,"select * from lecturer where lecturer='$lec' and dates='$lecd'");
if($row=mysqli_fetch_array($r))
	echo "Already Exists";
else{
$rn=mysqli_query($con,"insert into lecturer(lecturer,dates)values('$lec','$lecd')");

if($rn)
{
	 $_SESSION["addlecturer"]="Your Lecturer added Successfully";
    header("location:experience.php");
}
else
{
echo mysqli_error($con);
}
}
?>