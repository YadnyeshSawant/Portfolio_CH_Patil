function valid()
{
	var a=document.mine.cn.value;
	var b=document.mine.sc.value;
	var c=document.mine.type1.value;
	
 if(a=='')
 {
	 alert("Enter Category Name");
	 return false;
 }
 if(b=='')
 {
	 alert("Enter Subcategory");
	 return false;
 }
 if(c=='')
 {
	 alert("Enter Type");
	 return false;
 }
 return true;
}
