<?php
session_start();
include('db.php');

$ijp=$_POST["ijp"];



$r=mysqli_query($con,"select * from intjournalpublication where ijp='$ijp'");
if($row=mysqli_fetch_array($r))
	echo "Already Exists";
else{
$rn=mysqli_query($con,"insert into intjournalpublication(ijp)values('$ijp')");

if($rn)
{
	 $_SESSION["addijp"]="Your International Journal Publication added Successfully";
    header("location:intjournalpublication.php");
}
else
{
echo mysqli_error($con);
}
}
?>