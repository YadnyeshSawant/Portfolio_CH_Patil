<?php
include('db.php');

$cid=$_REQUEST["a"];

$r=mysqli_query($con,"update cart set status='3',dates=now() where id='$cid' ");

if($r)
	header("location:viewordernam.php");
else
	echo mysqli_error($con);

?>