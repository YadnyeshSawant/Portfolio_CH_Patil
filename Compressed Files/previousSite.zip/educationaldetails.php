<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dr.C.H. Patil</title>
</head>
<body>
    <h1 align='center'>Educational Details</h1>
    <table align="center" cellspacing='0' cellpadding='10' border='2px solid black' style="text-align: center;">
        <tr>
            <th>Examination Passed</th>
            <th>Year of Passing</th>
            <th>Board / University</th>
            <th>Percentage</th>
            <th>Class</th>
        </tr>
        <tr>
            <td>Ph.D.(Computer Science)</td>
            <td>5- May-2016</td>
            <td>Bharati Vidyapeeth Deemed University, Pune</td>
            <td colspan="2" >“A Study on Handwritten Marathi Word Recognition” under Dr. M. S. Prasad</td>
        </tr>
        <tr>
            <td>SET</td>
            <td>Feb – 2007</td>
            <td>Maharashtra</td>
            <td colspan="2" >PASS</td>
        </tr>
        <tr>
            <td>M.C.A.</td>
            <td>Jul – 2006</td>
            <td>Pune</td>
            <td>70.69</td>
            <td>Distinction</td>
        </tr>
        <tr>
            <td>B.Sc.
(Computer Science)
</td>
            <td>Jul -2003</td>
            <td>N.M.U., Jalgaon</td>
            <td>61.91%</td>
            <td>First class</td>
            
        </tr>
        <tr>
            <td>H.S.C. Science</td>
            <td>Feb -2000</td>
            <td>Nashik Board</td>
            <td>61%</td>
            <td>First class</td>
        </tr>
        <tr>
            <td>S.S.C.</td>
            <td>Mar -1998</td>
            <td>Nashik Board</td>
            <td>57.33%</td>
            <td>Second class</td>
        </tr>
    </table>
</body>
</html>